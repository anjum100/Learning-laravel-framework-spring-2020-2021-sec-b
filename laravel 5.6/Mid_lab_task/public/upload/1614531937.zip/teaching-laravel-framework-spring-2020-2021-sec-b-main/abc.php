<?php
	

	/*$name = "alamin";

	$student = ['1', 'name', 'cgpa'];
	echo $student[0];
	//$student = array();

	$student = ['id'=>'1', 'name'=>'alamin', 'cgpa'=>2.4];
	echo $student['id'];

	$students = [
					's1'=>['id'=>'1', 'name'=>'alamin', 'cgpa'=>2.4],
					's2'=>['id'=>'1', 'name'=>'alamin', 'cgpa'=>2.4],
					's3'=>['id'=>'1', 'name'=>'alamin', 'cgpa'=>2.4]
				];
	echo $students['s1']['name'];*/

	/*function sum($a=0, $b=0){

		return $a+$b;
	}

	sum();*/


	/*class Student 
	{
		private $name;
		private $id;
		private $cgpa;
		
		function __construct($name="", $id="", $cgpa="")
		{
			$this->name = $name;
			$this->id = $id;
			$this->cgpa = $cgpa;
		}

		public function getName(){
			return $this->name;
		}
	}*/


	//$s1 = new Student('alamin', '12', 3);

	/**
	 * 
	 */
/*	class CSStudent extends Student
	{
		private $dept;

		function __construct($dept)
		{
			parent::__construct('alamin', '12', '');
			$this->dept = $dept;
		}

	}*/

	/**
	 * 
	 */
/*	class SEStudent extends CSStudent
	{
		
		function __construct()
		{
			parent::__construct('SE');
		}
	}

	$std = new SEStudent('SE');
	echo $std->getName();*/